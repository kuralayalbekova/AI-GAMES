﻿#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

//namespace K_PathFinder.PFDebuger {
//    [ExecuteInEditMode()]
//    public class PFDDebugerScene : MonoBehaviour {




//        void OnDisable() {

//        }

//        void OnDestroy() {
  
//        }

                      












//    }
//}

#endif