﻿using K_PathFinder.Graphs;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace K_PathFinder.Samples {
    [ExecuteInEditMode]
    public class ExampleCellContent : NavMeshContent {
        //write your code here
    }
}