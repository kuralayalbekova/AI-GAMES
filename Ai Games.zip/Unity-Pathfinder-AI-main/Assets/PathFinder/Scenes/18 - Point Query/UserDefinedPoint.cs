﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace K_PathFinder.Samples {
    public class UserDefinedPoint : NavMeshContent {
        public bool isPointValid;
    }
}