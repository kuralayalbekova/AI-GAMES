All PathFinder stuff hided under Window > K-PathFinder

You can find manual under Window > K-PathFinder > Info > Manual

In Scenes folder there is example scenes. Scene from video are in "General Scene" folder

PathFinder folder location in current version should be in "Assets" or things will break